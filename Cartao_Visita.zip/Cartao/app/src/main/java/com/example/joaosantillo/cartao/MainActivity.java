package com.example.joaosantillo.cartao;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.ImageButton;

public class MainActivity extends AppCompatActivity {

    ImageButton linkedIn;
    ImageButton gitHub;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Para retirar a barra superior da activity, o código abaixo foi inserido.
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);

        //Botão para abrir página no LinkedIn
        linkedIn =(ImageButton)findViewById(R.id.imageButton);
        linkedIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                intent.setData(Uri.parse("https://www.linkedin.com/in/jo%C3%A3o-vitor-rodrigues-santillo-72b113a3/"));
                startActivity(intent);
            }
        });

        //Botão para abrir página no GitHub

        gitHub =(ImageButton)findViewById(R.id.imageButton3);
        gitHub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                intent.setData(Uri.parse("https://github.com/jvsantillo"));
                startActivity(intent);
            }
        });

    }
}
